# Snake and Apple Game

### Resources
https://www.youtube.com/playlist?list=PL-osiE80TeTt2d9bfVyTiXJA-UTHn6WwU - to learn the Basics of the Python

## final source code of this project is in main.py
